package com.example.demo_v01// UPDATE THIS TO YOUR PACKAGE NAME

import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class ChatActivity : AppCompatActivity() {

    private val TAG = "ChatbotApp"
    // Ensure this matches your Python Chat Server URL
    private val CHATBOT_URL = "http://10.0.2.2:5000/chat"

    private lateinit var chatHistoryTv: TextView
    private lateinit var userInputEt: EditText
    private lateinit var sendButton: Button
    private lateinit var chatScrollView: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat) // Links to the chat XML

        chatHistoryTv = findViewById(R.id.chat_history_tv)
        userInputEt = findViewById(R.id.user_input_et)
        sendButton = findViewById(R.id.send_button)
        chatScrollView = findViewById(R.id.chat_scroll_view)

        sendButton.setOnClickListener { sendMessage() }
    }

    private fun sendMessage() {
        val userMessage = userInputEt.text.toString().trim()
        if (userMessage.isEmpty()) return

        appendMessage("You", userMessage)
        userInputEt.setText("")
        ChatbotTask().execute(userMessage)
    }

    private fun appendMessage(sender: String, message: String) {
        runOnUiThread {
            chatHistoryTv.append("\n\n$sender: $message")
            chatScrollView.post { chatScrollView.fullScroll(View.FOCUS_DOWN) }
        }
    }

    // --- INTEGRATION: This function moves to the QR Project ---
    private fun moveToQrScreen(conclusionText: String) {
        val intent = Intent(this, QrActivity::class.java)
        // Pass the summary from Chat to QR
        intent.putExtra("QR_DATA", conclusionText)
        startActivity(intent)
        // Optional: Finish this activity so user cannot go back to chat
        finish()
    }

    private inner class ChatbotTask : AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg messages: String): String? {
            if (messages.isEmpty()) return null
            try {
                val url = URL(CHATBOT_URL)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; utf-8")
                conn.doOutput = true

                val jsonInput = JSONObject().put("message", messages[0]).toString()
                conn.outputStream.use { it.write(jsonInput.toByteArray()) }

                if (conn.responseCode == 200) {
                    return BufferedReader(InputStreamReader(conn.inputStream)).readText()
                }
                return "Error: ${conn.responseCode}"
            } catch (e: Exception) {
                return "Error: ${e.message}"
            }
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (result == null || result.startsWith("Error")) {
                appendMessage("System", result ?: "Error")
                return
            }

            try {
                val jsonResponse = JSONObject(result)
                val isFinished = jsonResponse.optBoolean("is_finished", false)

                if (isFinished) {
                    // 1. Get the conclusion text
                    val conclusionContent = jsonResponse.optString("conclusion_content", "Session Ended")

                    // 2. TRIGGER THE SWITCH TO QR ACTIVITY
                    moveToQrScreen(conclusionContent)
                } else {
                    // Normal chat response
                    val botResponse = jsonResponse.optString("response")
                    appendMessage("Chatbot", botResponse)
                }

            } catch (e: JSONException) {
                Log.e(TAG, "JSON Error", e)
            }
        }
    }
}