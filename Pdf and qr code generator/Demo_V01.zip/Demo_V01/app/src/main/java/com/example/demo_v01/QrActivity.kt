package com.example.demo_v01

import androidx.appcompat.app.AppCompatActivity
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.os.Bundle
import android.util.Base64
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class QrActivity : AppCompatActivity() {

    private lateinit var btnRefresh: Button
    private lateinit var tvStatus: TextView
    private lateinit var ivQRCode: ImageView
    private lateinit var webViewPdf: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr)

        btnRefresh = findViewById(R.id.btnRefresh)
        tvStatus = findViewById(R.id.tvStatus)
        ivQRCode = findViewById(R.id.ivQRCode)
        webViewPdf = findViewById(R.id.webViewPdf)

        // --- WEBVIEW SETTINGS FOR SCROLLING ---
        webViewPdf.webViewClient = WebViewClient()
        webViewPdf.settings.javaScriptEnabled = true
        // These ensure the scrollbars are visible and the viewport fits the screen
        webViewPdf.isVerticalScrollBarEnabled = true
        webViewPdf.settings.loadWithOverviewMode = true
        webViewPdf.settings.useWideViewPort = true

        FetchDataTask().execute()

        btnRefresh.setOnClickListener {
            FetchDataTask().execute()
        }
    }

    private inner class FetchDataTask : AsyncTask<Void, Void, String?>() {

        override fun onPreExecute() {
            tvStatus.text = "Fetching content..."
        }

        override fun doInBackground(vararg params: Void?): String? {
            val SERVER_URL = "http://10.0.2.2:5000/api/generate"
            try {
                val url = URL(SERVER_URL)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 5000
                conn.connect()

                if (conn.responseCode == 200) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    return reader.readText()
                } else {
                    return "Error: ${conn.responseCode}"
                }
            } catch (e: Exception) {
                return "Exception: ${e.message}"
            }
        }

        override fun onPostExecute(result: String?) {
            if (result == null || result.startsWith("Error") || result.startsWith("Exception")) {
                tvStatus.text = "Failed: $result"
                return
            }

            try {
                val jsonObject = JSONObject(result)
                val qrBase64 = jsonObject.optString("qr_image")
                val htmlContent = jsonObject.optString("html_content")

                if (qrBase64.isNotEmpty()) {
                    val decodedString = Base64.decode(qrBase64, Base64.DEFAULT)
                    val decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                    ivQRCode.setImageBitmap(decodedByte)
                }

                if (htmlContent.isNotEmpty()) {
                    // Load the HTML. The WebView will handle scrolling automatically
                    // because the XML layout gives it a fixed area (layout_weight=1)
                    webViewPdf.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
                }

                tvStatus.text = "Report Loaded from JSON"

            } catch (e: Exception) {
                tvStatus.text = "Error parsing data: ${e.message}"
            }
        }
    }
}