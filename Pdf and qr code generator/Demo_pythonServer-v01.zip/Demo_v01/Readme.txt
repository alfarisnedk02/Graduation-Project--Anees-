this code represent a chatbot with runtime chatbot, and integrated with PDF and qrCode generator, designed to be linked with interface, I am using android studio as interface.
